package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.5-1";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2023-06-21 13:59"
];

1;

